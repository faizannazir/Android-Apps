package com.dominicsilveira.parkingsystem.classes;


public class UpiInfo {
    public String upiId,upiName;

    public UpiInfo(){}

    public UpiInfo(String upiId, String upiName){
        this.upiId=upiId;
        this.upiName=upiName;
    }
}
